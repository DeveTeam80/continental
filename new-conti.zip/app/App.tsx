import React from "react";
import StickyIntro from "./components/StickyIntro";
import MapSection from "./components/MapSection";
import Header from "./components/Header";
import ArtDecoSection from "./components/ArtDecoSection";
import ArchitectureSection from "./components/Architecture";
import ArchitectureDetailsSection from "./components/ArchitectureDetailSection";
import JoySection from "./components/JoySection";
import "@/app/globals.css";
import InteriorsSection from "./components/InteriorSection";
import PlansSection from "./components/ApartmentSection";
import NewEraSection from "./components/CTA";
import "@/app/globals.css"
const App: React.FC = () => {
  return (
    <main className="relative bg-white">
      <Header />

      {/* Hero Sticky Section */}
      <StickyIntro />
      <ArtDecoSection />
      {/* Content Spacer */}
      <div className="h-[20vh] bg-white flex items-center justify-center">
        <div className="w-px h-24 bg-gradient-to-b from-[#ca8c19] to-transparent opacity-30" />
      </div>

      <ArchitectureSection />
      <ArchitectureDetailsSection />
      <JoySection/>
            {/* <ArtDecoSection /> */}
      <InteriorsSection />
      <PlansSection />
      <NewEraSection />
      <footer className="bg-white text-[#825541] py-24 border-t border-[#825541]/10">
        <div className="container mx-auto px-6 lg:px-12 grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-4xl font-serif mb-8 text-[#ca8c19]">Aristo</h3>
            <p className="text-[#825541]/70 max-w-md leading-relaxed">
              Crafting timeless living spaces inspired by the golden era of Art
              Deco, blending classical architectural values with modern luxury
              technologies.
            </p>
          </div>

          {/* Address */}
          <div>
            <h4 className="uppercase text-xs tracking-[0.3em] text-[#ca8c19] mb-6">
              Address
            </h4>
            <p className="text-[#825541]/70">
              123 Renaissance Ave
              <br />
              Metropolis, QC 50502
            </p>
          </div>

          {/* Contact */}
          <div>
            <h4 className="uppercase text-xs tracking-[0.3em] text-[#ca8c19] mb-6">
              Contact
            </h4>
            <p className="text-[#825541]/70">
              hello@aristo.estate
              <br />
              +1 (234) 567 890
            </p>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="container mx-auto px-6 lg:px-12 mt-24 pt-8 border-t border-[#825541]/10 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-[10px] uppercase tracking-widest text-[#825541]/50">
            © 2024 Aristo Estates. All rights reserved.
          </p>

          <div className="flex gap-8 text-[10px] uppercase tracking-widest text-[#825541]/50">
            <a href="#" className="hover:text-[#ca8c19] transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-[#ca8c19] transition-colors">
              Terms of Use
            </a>
          </div>
        </div>
      </footer>
    </main>
  );
};

export default App;
