"use client";

import React from "react";

export default function JoyEditorialSection() {
  return (
    <section className="relative bg-white text-[#825541] py-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">

        {/* Images Row */}
        <div className="grid grid-cols-12 gap-10 items-start mb-12">
          {/* Large Image */}
          <div className="col-span-12 md:col-span-6">
            <img
              src="/assets/images/media/landing/joy/image-1@md.webp"
              alt=""
              className="w-full h-auto object-cover"
            />
          </div>

          {/* Small Image */}
          <div className="col-span-6 md:col-span-3 md:col-start-10">
            <img
              src="/assets/images/media/landing/joy/image-2@md.webp"
              alt=""
              className="w-full h-auto object-cover"
            />
          </div>
        </div>

        {/* Editorial Wrapped Text */}
        <p className="joy-editorial-text text-lg md:text-xl leading-relaxed tracking-wide max-w-full text-[#825541]/80">
          <span className="text-[#ca8c19] font-medium">
            ERA brings eternal joy to the capital center. Here one can delve into the stories of historic
          buildings, like turning pages of a memoir. One can take his children to
          kindergartens and schools, that pave the way for a bright future. One
          can find solitude in picturesque parks or have fun with friends all
          night long.</span>
        </p>

      </div>
    </section>
  );
}
