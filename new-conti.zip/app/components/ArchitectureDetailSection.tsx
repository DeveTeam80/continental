
import React from 'react';
import { motion } from 'framer-motion';
import { Play } from 'lucide-react';

const ArchitectureDetailsSection: React.FC = () => {
  return (
    <section className="relative min-h-screen bg-[#f9f4ef] text-[#ca8c19] py-24 md:py-32 overflow-hidden">
      {/* Art Deco Flower SVG Pattern Background */}
      <div className="absolute inset-0 z-0 opacity-[0.15] pointer-events-none flex justify-center items-center">
        <svg width="842" height="1151" viewBox="0 0 842 1151" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-[80%] h-auto max-w-4xl">
          <path d="M841 262.147C841 412.175 730.822 510.2 619.654 594.241C532.277 660.297 421 773.504 421 888.853M841 262.147V524.294C841 674.322 730.822 772.347 619.654 856.388C532.277 922.444 421 1035.65 421 1151M841 262.147V0C841 150.028 730.822 248.053 619.654 332.094C532.277 398.15 421 511.357 421 626.706M421 1151C421 1035.65 309.723 922.444 222.346 856.388C111.178 772.347 1 674.322 1 524.294V262.147M421 1151V888.853M421 888.853C421 773.504 309.723 660.297 222.346 594.241C111.178 510.2 1 412.175 1 262.147M421 888.853V626.706M421 626.706C421 511.357 309.723 398.15 222.346 332.094C111.178 248.053 1 150.028 1 0V262.147M421 626.706V365.119M619.654 70.5075C532.277 136.563 421 249.771 421 365.119M421 365.119C421 249.771 309.723 136.563 222.346 70.5075M421 365.119V102.972" 
            stroke="#CF8F7D" strokeWidth="1" />
        </svg>
      </div>

      <div className="container mx-auto px-6 relative z-10 max-w-7xl">
        {/* Intro Text Block */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-center mb-24 md:mb-40"
        >
          <p className="text-2xl md:text-3xl lg:text-4xl font-light text-[#ca8c19] leading-relaxed max-w-5xl mx-auto italic">
            Art Deco has captivated artists, writers, architects, and designers for over a century. 
            Its vibrant aesthetic promises unforgettable experiences and continues to inspire with its theatrical flair and elegance.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-24 items-start">
          
          {/* Left Column: Quote and Interview */}
          <div className="lg:col-span-5 flex flex-col gap-20">
            {/* The Architect's Quote */}
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="border-l border-[#cf8f7d] pl-8"
            >
              <blockquote className="text-xl md:text-2xl font-serif text-[#ca8c19] leading-relaxed mb-8">
                «The fundamental idea behind ERA is the tradition of the high-rise architecture of the last century, which forms a unique, recognisable silhouette of the world's major cities ».
              </blockquote>
              <div className="flex flex-col">
                <span className="text-sm font-bold tracking-widest uppercase text-[#ca8c19]">Grigorios Gavalidis</span>
                <span className="text-xs tracking-widest uppercase text-[#ca8c19]">founder of GAFA bureau</span>
              </div>
            </motion.div>

            {/* Architects Interview Card */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="group cursor-pointer"
            >
              <p className="text-[10px] font-bold tracking-[0.4em] uppercase text-[#cf8f7d] mb-6">ARCHITECTS INTERVIEW</p>
              <div className="relative aspect-video rounded-sm overflow-hidden shadow-xl">
                <img 
                  src="https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=2070&auto=format&fit=crop" 
                  alt="Architects" 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
                />
                <div className="absolute inset-0 bg-[#051936]/30 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full border border-white/40 flex items-center justify-center backdrop-blur-sm group-hover:scale-110 group-hover:bg-[#cf8f7d] group-hover:border-[#cf8f7d] transition-all duration-500">
                    <Play size={24} className="text-white fill-current translate-x-0.5" />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Main Visual and Navigation */}
          <div className="lg:col-span-7 relative">
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 1.2, delay: 0.3 }}
              className="relative aspect-square md:aspect-[4/5] overflow-hidden rounded-sm shadow-2xl"
            >
              <img 
                src="assets/images/horizon/horizon-3.png" 
                alt="Architecture Close Up" 
                className="w-full h-full object-cover"
              />
              
              {/* Architecture CTA Button */}
              <div className="absolute bottom-12 right-12 z-20">
                <button className="bg-[#ca8c19] text-white px-10 py-5 rounded-sm flex items-center gap-4 text-xs font-bold uppercase tracking-[0.3em] hover:bg-[#051936] transition-colors duration-500 shadow-2xl group">
                  Architecture
                  <div className="w-8 h-px bg-white/40 group-hover:w-12 transition-all duration-500" />
                </button>
              </div>

              {/* Cinematic Vignette */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#051936]/40 via-transparent to-transparent pointer-events-none" />
            </motion.div>

            {/* Decorative Grid Lines Overlay (Architectural feel) */}
            <div className="absolute -top-12 -left-12 w-32 h-32 border-t border-l border-[#cf8f7d]/30 pointer-events-none" />
            <div className="absolute -bottom-12 -right-12 w-32 h-32 border-b border-r border-[#cf8f7d]/30 pointer-events-none" />
          </div>

        </div>
      </div>

      {/* Subtle bottom scroll hint */}
      {/* <div className="mt-40 flex justify-center">
        <div className="w-px h-24 bg-gradient-to-b from-[#cf8f7d] to-transparent" />
      </div> */}
    </section>
  );
};

export default ArchitectureDetailsSection;
