import React, { useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';
import BackgroundFlower from './BackgroundFlower';

const StickyIntro: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 60,
    damping: 25,
    restDelta: 0.001
  });

  const clipPath = useTransform(
    smoothProgress,
    [0, 0.5, 0.8],
    [
      "inset(70% 20% 0% 20%)",
      "inset(15% 10% 5% 10%)",
      "inset(0% 0% 0% 0%)"
    ]
  );

  const imageScale = useTransform(smoothProgress, [0, 0.8], [1.3, 1]);
  const imageY = useTransform(smoothProgress, [0, 0.8], ["10%", "0%"]);

  const leftX = useTransform(smoothProgress, [0, 0.5], ["0%", "-10%"]);
  const leftY = useTransform(smoothProgress, [0, 0.5], ["0%", "-5%"]);
  const rightX = useTransform(smoothProgress, [0, 0.5], ["0%", "10%"]);
  const rightY = useTransform(smoothProgress, [0, 0.5], ["0%", "5%"]);

  const subtitleY = useTransform(smoothProgress, [0, 0.4], ["0%", "-100%"]);
  const subtitleOpacity = useTransform(smoothProgress, [0, 0.3], [1, 0]);

  const badgeOpacity = useTransform(smoothProgress, [0.3, 0.5], [0, 1]);
  const badgeScale = useTransform(smoothProgress, [0.3, 0.5], [0.8, 1]);

  return (
    <div ref={containerRef} className="relative h-[400vh] w-full">
      <div className="sticky top-0 h-screen w-full overflow-hidden bg-white">
        
        {/* Background Decorative Patterns */}
        <motion.div 
          style={{ opacity: useTransform(smoothProgress, [0, 0.5], [0.4, 0.1]) }}
          className="absolute inset-0 z-0 pointer-events-none"
        >
          <BackgroundFlower />
        </motion.div>

        {/* Image */}
        <motion.div 
          style={{ clipPath, scale: imageScale, y: imageY }}
          className="absolute inset-0 z-10 flex items-center justify-center overflow-hidden"
        >
          <img 
            src="/assets/images/horizon/horizon-4.png" 
            alt="Horizon view"
            className="w-full h-full object-cover brightness-90"
          />

          {/* 3D Map Badge */}
          <motion.div 
            style={{ opacity: badgeOpacity, scale: badgeScale }}
            className="absolute bottom-16 right-16 z-30"
          >
            <div className="bg-[#ca8c19]/90 backdrop-blur-md px-8 py-3 rounded-full flex items-center gap-6 shadow-2xl cursor-pointer hover:bg-white transition-colors duration-500">
              <div className="flex flex-col">
                <span className="text-[10px] font-bold tracking-[0.3em] text-[#1f2933] uppercase opacity-60">
                  Explore
                </span>
                <span className="text-sm font-bold tracking-[0.1em] text-[#1f2933] uppercase">
                  3D-MAP
                </span>
              </div>

              <div className="w-10 h-10 rounded-full border border-[#1f2933]/20 flex items-center justify-center">
                <div className="w-6 h-6 rounded-sm bg-[#1f2933]/10 border border-[#1f2933]/40 flex items-center justify-center text-[8px] font-bold text-[#1f2933]">
                  3D
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>

        {/* Typography */}
        <div className="relative z-20 h-full w-full flex flex-col items-center justify-center pointer-events-none px-12">
          <motion.div 
            style={{ y: subtitleY, opacity: subtitleOpacity }}
            className="absolute top-[35%] text-[10px] md:text-xs font-semibold tracking-[0.4em] uppercase text-[#1f2933]/70"
          >
            THE PLACE WHERE LIFE BECOMES ART
          </motion.div>

          <div className="w-full max-w-[1440px] flex justify-between items-baseline mt-20">
            <motion.div style={{ x: leftX, y: leftY }} className="flex flex-col">
              <h1 className="text-[10vw] md:text-[8vw] leading-[0.85] font-light tracking-tighter text-[#1f2933]">
                HERITAGE
              </h1>
              <h1 className="text-[10vw] md:text-[8vw] leading-[0.85] font-light tracking-tighter italic font-serif text-[#1f2933]/80">
                MEETS
              </h1>
            </motion.div>

            <motion.div style={{ x: rightX, y: rightY }} className="text-right">
              <h1 className="text-[10vw] md:text-[8vw] leading-[0.85] font-light tracking-tighter text-[#ca8c19]">
                HORIZON
              </h1>
            </motion.div>
          </div>
        </div>

        {/* Vertical Lines */}
        <div className="absolute left-1/2 top-0 h-full w-px bg-gradient-to-b from-black/10 via-black/5 to-transparent z-10 -translate-x-1/2" />
        <div className="absolute left-[30%] top-0 h-full w-px bg-black/5 z-10" />
        <div className="absolute right-[30%] top-0 h-full w-px bg-black/5 z-10" />

      </div>
    </div>
  );
};

export default StickyIntro;
