import React, { useRef } from "react";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";

const NewEraSection: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  });

  const smoothScroll = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
  });

  /* Parallax background */
  const imgY = useTransform(smoothScroll, [0, 1], ["0%", "-20%"]);

  /* Text reveal */
  const textOpacity = useTransform(smoothScroll, [0.1, 0.3], [0, 1]);
  const textY = useTransform(smoothScroll, [0.1, 0.3], [40, 0]);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen bg-white text-[#825541] flex items-center justify-center py-32 overflow-hidden"
    >
      {/* ───── Content ───── */}
      <div className="relative z-20 max-w-5xl mx-auto px-6 text-center flex flex-col items-center">

        <motion.p
          style={{ opacity: textOpacity, y: textY }}
          className="text-[#ca8c19] text-sm md:text-base font-light tracking-[0.4em] uppercase mb-8"
        >
          A place where life becomes art
        </motion.p>

        <motion.h2
          style={{
            opacity: useTransform(smoothScroll, [0.15, 0.35], [0, 1]),
            y: useTransform(smoothScroll, [0.15, 0.35], [60, 0]),
          }}
          className="text-4xl md:text-5xl font-serif italic leading-tight mb-20 max-w-4xl text-[#825541]"
        >
          A new ERA for the city, a new chapter in your life.
        </motion.h2>

        {/* ───── Request a Call Button ───── */}
        <motion.div
          style={{
            opacity: useTransform(smoothScroll, [0.25, 0.45], [0, 1]),
            scale: useTransform(smoothScroll, [0.25, 0.45], [0.9, 1]),
          }}
        >
          <button
            className="
              group
              w-28 h-28 md:w-36 md:h-36
              rounded-full
              bg-[#ca8c19]
              text-white
              flex flex-col items-center justify-center
              shadow-xl
              transition-all duration-500
              hover:scale-105
              hover:bg-[#b97b14]
            "
          >
            <span className="text-[10px] font-semibold tracking-[0.5em] uppercase">
              Request
            </span>
            <span className="text-xl md:text-2xl font-serif italic leading-none">
              a call
            </span>

            {/* Inner ring */}
            <span className="absolute inset-3 rounded-full border border-white/30 group-hover:border-white/50 transition-colors" />
          </button>
        </motion.div>
      </div>

      {/* ───── Parallax Background ───── */}
      <div className="absolute inset-0 z-10 pointer-events-none">
        <motion.div
          style={{ y: imgY }}
          className="absolute inset-0 h-[130%]"
        >
          <img
            src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=2070&auto=format&fit=crop"
            alt="New Era Architecture"
            className="w-full h-full object-cover brightness-[0.9]"
          />
        </motion.div>

        {/* Soft vignette */}
        <div className="absolute inset-0 bg-gradient-to-t from-white via-white/70 to-white" />
      </div>

      {/* ───── Decorative Lines ───── */}
      <div className="absolute left-1/2 top-0 bottom-0 w-px bg-[#825541]/10 -translate-x-1/2" />
      <div className="absolute left-[20%] top-0 bottom-0 w-px bg-[#825541]/10" />
      <div className="absolute right-[20%] top-0 bottom-0 w-px bg-[#825541]/10" />
    </section>
  );
};

export default NewEraSection;
