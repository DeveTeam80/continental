import React, { useRef } from "react";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import { ArrowRight } from "lucide-react";

const PlansSection: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"],
  });

  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
  });

  /* Parallax + reveal */
  const bgScale = useTransform(smoothProgress, [0, 1], [1.1, 1]);
  const bgOpacity = useTransform(
    smoothProgress,
    [0, 0.2, 0.8, 1],
    [0, 1, 1, 0.9]
  );

  const titleX = useTransform(smoothProgress, [0, 0.4], [100, 0]);
  const titleOpacity = useTransform(smoothProgress, [0, 0.3], [0, 1]);

  const cardsY = useTransform(smoothProgress, [0.2, 0.6], [100, 0]);
  const cardsOpacity = useTransform(smoothProgress, [0.2, 0.5], [0, 1]);

  return (
    <section
      id="plans"
      ref={containerRef}
      className="relative h-[300vh] bg-white text-[#825541]"
    >
      <div className="sticky top-0 h-screen w-full overflow-hidden">

        {/* Background image */}
        <motion.div
          style={{ scale: bgScale, opacity: bgOpacity }}
          className="absolute inset-0 z-0"
        >
          <img
            src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2070&auto=format&fit=crop"
            alt="Architecture Background"
            className="w-full h-full object-cover brightness-[0.95]"
          />

          {/* Subtle architectural texture */}
          <div className="absolute inset-0 opacity-[0.04] bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]" />
        </motion.div>

        {/* Content */}
        <div className="relative z-10 h-full flex flex-col justify-center px-6 max-w-7xl mx-auto">

          {/* Heading */}
          <motion.h2
            style={{ x: titleX, opacity: titleOpacity }}
            className="text-[12vw] font-serif uppercase leading-none text-right mb-16 text-[#825541]pointer-events-none"
          >
            Apartments
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-end">
            <motion.div
              style={{ y: cardsY, opacity: cardsOpacity }}
              className="
                md:col-span-8
                grid grid-cols-1 md:grid-cols-2
                gap-px
                bg-[#825541]/10
                border border-[#825541]/15
                backdrop-blur-sm
                overflow-hidden
                rounded-sm
                shadow-xl
              "
            >
              {/* Card 1 */}
              <a
                href="/flats"
                className="
                  group relative p-12 md:p-16 h-[50vh] md:h-[60vh]
                  flex flex-col justify-between
                  transition-colors duration-700
                  hover:bg-[#ca8c19]/5
                "
              >
                <div className="relative z-10">
                  <p className="text-2xl md:text-3xl font-serif text-[#ca8c19] mb-4 group-hover:text-[#825541] transition-colors">
                    Select by <br /> criteria
                  </p>
                  <p className="text-xs uppercase tracking-[0.4em] text-[#825541]/50">
                    Parametric Search
                  </p>
                </div>

                {/* Decorative arch */}
                <div className="absolute inset-0 opacity-20 group-hover:opacity-40 transition-opacity flex items-center justify-center">
                  <svg
                    viewBox="0 0 422 718"
                    className="h-[120%] w-auto stroke-[#ca8c19]"
                  >
                    <path strokeWidth="0.5" d="M421 262V393C421 468 365 516 310 558C266 592 211 648 211 706" />
                    <path strokeWidth="1" d="M211 0V718" />
                    <path strokeWidth="0.5" d="M1 262V393C1 468 56 516 111 558C154 592 211 648 211 706" />
                  </svg>
                </div>

                <div className="relative z-10 flex justify-between items-end">
                  <div className="w-16 h-16 rounded-full border border-[#825541]/30 flex items-center justify-center group-hover:bg-[#ca8c19] group-hover:border-[#ca8c19] transition-all">
                    <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                  </div>

                  <img
                    src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=400&auto=format&fit=crop"
                    className="w-32 opacity-40 grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-1000"
                    alt=""
                  />
                </div>
              </a>

              {/* Card 2 */}
              <a
                href="/visual-search"
                className="
                  group relative p-12 md:p-16 h-[50vh] md:h-[60vh]
                  flex flex-col justify-between
                  transition-colors duration-700
                  hover:bg-[#ca8c19]/5
                  border-t md:border-t-0 md:border-l border-[#825541]/15
                "
              >
                <div className="relative z-10">
                  <p className="text-2xl md:text-3xl font-serif text-[#ca8c19] mb-4 group-hover:text-[#825541] transition-colors">
                    Visual <br /> Selection
                  </p>
                  <p className="text-xs uppercase tracking-[0.4em] text-[#825541]/50">
                    Facade Interface
                  </p>
                </div>

                <div className="relative z-10 flex justify-between items-end">
                  <div className="w-16 h-16 rounded-full border border-[#825541]/30 flex items-center justify-center group-hover:bg-[#ca8c19] group-hover:border-[#ca8c19] transition-all">
                    <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                  </div>

                  <img
                    src="https://images.unsplash.com/photo-1577493340887-b7bfff550145?q=80&w=400&auto=format&fit=crop"
                    className="w-32 opacity-40 grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-1000"
                    alt=""
                  />
                </div>
              </a>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PlansSection;
